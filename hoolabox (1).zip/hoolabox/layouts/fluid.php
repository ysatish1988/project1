<?php require UC_ROOT.'/parts/section/header.php'; ?>

<?php require_once UC_ROOT.'/pages/'.$page.'.php'; ?>

<?php require UC_ROOT.'/parts/section/footer.php';?>